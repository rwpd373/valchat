import os
import time

time.sleep(5)
os.startfile("bot.py")
time.sleep(2)
quit()
# really, that's all that is in this script. lol.
# this is just to make it so the bot.py file can launch again